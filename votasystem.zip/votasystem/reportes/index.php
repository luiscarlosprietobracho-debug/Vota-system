<?php

session_start();

if(!isset($_SESSION['usuario'])){

    header("Location: ../login.php");

}

include("../conexion/conexion.php");

/* CONSULTAR RESULTADOS */

$sql = "SELECT

eleccion.titulo AS eleccion,
candidato.nombre AS candidato,
COUNT(voto.id_voto) AS total_votos

FROM candidato

INNER JOIN eleccion
ON candidato.id_eleccion = eleccion.id_eleccion

LEFT JOIN voto
ON candidato.id_candidato = voto.id_candidato

GROUP BY candidato.id_candidato

ORDER BY eleccion.titulo ASC,
total_votos DESC";

$resultado = mysqli_query($conexion, $sql);

?>

<!DOCTYPE html>
<html lang="es">
<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Reportes</title>

    <link rel="stylesheet"
          href="../css/dashboard.css">

</head>
<body>

<div class="container">

    <!-- SIDEBAR -->

    <aside class="sidebar">

        <h2>VotaSystem</h2>

        <ul>

            <li>
                <a href="../dashboard/index.php">
                    Dashboard
                </a>
            </li>

            <li>
                <a href="../elecciones/index.php">
                    Elecciones
                </a>
            </li>

            <li>
                <a href="../candidatos/index.php">
                    Candidatos
                </a>
            </li>

            <li>
                <a href="../usuarios/index.php">
                    Usuarios
                </a>
            </li>

            <li>
                <a href="index.php">
                    Reportes
                </a>
            </li>

            <li>
                <a href="../logout.php">
                    Cerrar sesión
                </a>
            </li>

        </ul>

    </aside>

    <!-- CONTENIDO -->

    <main class="main-content">

        <header class="top-bar">

            <h1>Resultados de Votaciones</h1>

        </header>

        <table>

            <tr>

                <th>Elección</th>
                <th>Candidato</th>
                <th>Total Votos</th>

            </tr>

            <?php while($fila = mysqli_fetch_assoc($resultado)){ ?>

            <tr>

                <td>
                    <?php echo $fila['eleccion']; ?>
                </td>

                <td>
                    <?php echo $fila['candidato']; ?>
                </td>

                <td>
                    <?php echo $fila['total_votos']; ?>
                </td>

            </tr>

            <?php } ?>

        </table>

    </main>

</div>

</body>
</html>