<?php

session_start();

if(!isset($_SESSION['usuario'])){

    header("Location: ../login.php");

}

include("../conexion/conexion.php");

/* USUARIO */

$id_usuario = $_SESSION['id_usuario'];

/* ELECCIONES ACTIVAS */

$sql = "SELECT * FROM eleccion
WHERE estado='Activa'";

$elecciones = mysqli_query($conexion, $sql);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Panel de Votación</title>

    <link rel="stylesheet"
          href="../css/dashboard.css">

</head>
<body>

<div class="container">

    <!-- SIDEBAR -->

    <aside class="sidebar">

        <h2>VotaSystem</h2>

        <ul>

            <li>
                <a href="index.php">
                    Votaciones
                </a>
            </li>

            <li>
                <a href="../logout.php">
                    Cerrar sesión
                </a>
            </li>

        </ul>

    </aside>

    <!-- CONTENIDO -->

    <main class="main-content">

        <header class="top-bar">

            <h1>
                Bienvenido,
                <?php echo $_SESSION['usuario']; ?>
            </h1>

        </header>

        <h2>Elecciones Activas</h2>

        <?php while($eleccion = mysqli_fetch_assoc($elecciones)){ ?>

        <div class="card">

            <h3>
                <?php echo $eleccion['titulo']; ?>
            </h3>

            <p>
                <?php echo $eleccion['descripcion']; ?>
            </p>

            <hr>

            <h4>Candidatos</h4>

            <?php

            /* CONSULTAR CANDIDATOS */

            $id_eleccion = $eleccion['id_eleccion'];

            $sql_candidatos = "SELECT * FROM candidato
            WHERE id_eleccion='$id_eleccion'
            AND estado='Activo'";

            $candidatos = mysqli_query($conexion, $sql_candidatos);

            ?>

            <?php while($candidato = mysqli_fetch_assoc($candidatos)){ ?>

            <div class="candidate-card">

                <h3>
                    <?php echo $candidato['nombre']; ?>
                </h3>

                <p>
                    <?php echo $candidato['propuesta']; ?>
                </p>

                <form action="votar.php" method="POST">

                    <input type="hidden"
                           name="id_eleccion"
                           value="<?php echo $id_eleccion; ?>">

                    <input type="hidden"
                           name="id_candidato"
                           value="<?php echo $candidato['id_candidato']; ?>">

                    <button type="submit" class="btn">
                        Votar
                    </button>

                </form>

            </div>

            <?php } ?>

        </div>

        <?php } ?>

    </main>

</div>

</body>
</html>