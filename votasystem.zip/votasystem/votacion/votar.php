<?php

session_start();

include("../conexion/conexion.php");

/* USUARIO LOGUEADO */

$id_usuario = $_SESSION['id_usuario'];

/* DATOS DEL FORM */

$id_eleccion = $_POST['id_eleccion'];
$id_candidato = $_POST['id_candidato'];

/* VALIDAR SI YA VOTO */

$sql_validar = "SELECT * FROM voto
WHERE id_usuario='$id_usuario'
AND id_eleccion='$id_eleccion'";

$validacion = mysqli_query($conexion, $sql_validar);

/* SI YA VOTO */

if(mysqli_num_rows($validacion) > 0){

    echo "
    <script>

        alert('Ya realizaste tu voto en esta elección');

        window.location='index.php';

    </script>
    ";

}else{

    /* GUARDAR VOTO */

    $sql = "INSERT INTO voto
    (
        id_usuario,
        id_eleccion,
        id_candidato,
        fecha_voto
    )
    VALUES
    (
        '$id_usuario',
        '$id_eleccion',
        '$id_candidato',
        NOW()
    )";

    $resultado = mysqli_query($conexion, $sql);

    if($resultado){

        echo "
        <script>

            alert('Voto registrado correctamente');

            window.location='index.php';

        </script>
        ";

    }else{

        echo "
        <script>

            alert('Error al registrar voto');

            window.location='index.php';

        </script>
        ";

    }

}

?>