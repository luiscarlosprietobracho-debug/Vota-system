<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - VotaSystem</title>

    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="login-container">

    <h1>VotaSystem</h1>
    <p>Elecciones estudiantiles</p>

    <form action="validar_login.php" method="POST">

        <input type="email" name="correo" placeholder="Correo electrónico" required>

        <input type="password" name="password" placeholder="Contraseña" required>

        <button type="submit">Iniciar Sesión</button>

    </form>

</div>

</body>
</html>