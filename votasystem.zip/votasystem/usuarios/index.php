<?php

session_start();

if(!isset($_SESSION['usuario'])){
    header("Location: ../login.php");
}

include("../conexion/conexion.php");

/* CONSULTA */

$sql = "SELECT usuario.*, rol.nombre AS rol_nombre
FROM usuario
INNER JOIN rol
ON usuario.id_rol = rol.id_rol";
$resultado = mysqli_query($conexion, $sql);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios</title>

    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>

<div class="container">

    <aside class="sidebar">

        <h2>VotaSystem</h2>

        <ul>
            <li><a href="../dashboard/index.php">Dashboard</a></li>
            <li><a href="../elecciones/index.php">Elecciones</a></li>
            <li><a href="../candidatos/index.php">Candidatos</a></li>
            <li><a href="index.php">Usuarios</a></li>
            <li><a href="../reportes/index.php">Reportes</a></li>
            <li><a href="../logout.php">Cerrar sesión</a></li>
        </ul>

    </aside>

    <main class="main-content">

        <header class="top-bar">

            <h1>Gestión de Usuarios</h1>

            <a href="crear.php" class="btn">
                Nuevo Usuario
            </a>

        </header>

        <table>

            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Rol</th>
                <th>Acciones</th>
            </tr>

            <?php while($fila = mysqli_fetch_assoc($resultado)){ ?>

            <tr>

                <td><?php echo $fila['id_usuario']; ?></td>

                <td><?php echo $fila['nombre']; ?></td>

                <td><?php echo $fila['correo']; ?></td>

                <td><?php echo $fila['rol_nombre']; ?></td>

                <td>

                    <a class="btn-editar"
                    href="editar.php?id=<?php echo $fila['id_usuario']; ?>">
                    Editar
                    </a>

                    <a class="btn-eliminar"
                    href="eliminar.php?id=<?php echo $fila['id_usuario']; ?>">
                    Eliminar
                    </a>

                </td>

            </tr>

            <?php } ?>

        </table>

    </main>

</div>

</body>
</html>