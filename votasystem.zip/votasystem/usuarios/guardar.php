<?php

include("../conexion/conexion.php");

/* RECIBIR DATOS */

$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$documento = $_POST['documento'];
$password = $_POST['password'];
$id_rol = $_POST['id_rol'];

/* VALIDAR CORREO */

$sql_correo = "SELECT * FROM usuario
WHERE correo='$correo'";

$resultado_correo = mysqli_query($conexion, $sql_correo);

/* SI EXISTE CORREO */

if(mysqli_num_rows($resultado_correo) > 0){

    echo "
    <script>

        alert('El correo ya está registrado en otro usuario');

        window.location='crear.php';

    </script>
    ";

    exit();

}

/* VALIDAR DOCUMENTO */

$sql_documento = "SELECT * FROM usuario
WHERE documento='$documento'";

$resultado_documento = mysqli_query($conexion, $sql_documento);

/* SI EXISTE DOCUMENTO */

if(mysqli_num_rows($resultado_documento) > 0){

    echo "
    <script>

        alert('El documento ya está registrado en otro usuario');

        window.location='crear.php';

    </script>
    ";

    exit();

}

/* INSERTAR USUARIO */

$sql = "INSERT INTO usuario
(
    nombre,
    correo,
    documento,
    password,
    id_rol
)
VALUES
(
    '$nombre',
    '$correo',
    '$documento',
    '$password',
    '$id_rol'
)";

$resultado = mysqli_query($conexion, $sql);

/* VALIDAR */

if($resultado){

    echo "
    <script>

        alert('Usuario registrado correctamente');

        window.location='index.php';

    </script>
    ";

}else{

    echo "
    <script>

        alert('Error al registrar usuario');

        window.location='crear.php';

    </script>
    ";

}

?>