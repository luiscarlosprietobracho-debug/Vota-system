<?php

session_start();

if(!isset($_SESSION['usuario'])){
    header("Location: ../login.php");
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo Usuario</title>

    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>

<div class="container">

    <aside class="sidebar">

        <h2>VotaSystem</h2>

        <ul>
            <li><a href="../dashboard/index.php">Dashboard</a></li>
            <li><a href="../elecciones/index.php">Elecciones</a></li>
            <li><a href="../candidatos/index.php">Candidatos</a></li>
            <li><a href="index.php">Usuarios</a></li>
            <li><a href="../reportes/index.php">Reportes</a></li>
            <li><a href="../logout.php">Cerrar sesión</a></li>
        </ul>

    </aside>

    <main class="main-content">

        <header class="top-bar">
            <h1>Registrar Usuario</h1>
        </header>

        <div class="form-container">

            <form action="guardar.php" method="POST">

                <label>Nombre</label>
                <input type="text" name="nombre" required>

                <label>Correo</label>
                <input type="email" name="correo" required>

                <label>Documento</label>
<input type="text" name="documento" required>

                <label>Contraseña</label>
                <input type="password" name="password" required>

                <label>Rol</label>

                <select name="id_rol" required>

                    <option value="1">
    Administrador
</option>

<option value="2">
    Estudiante
</option>

<option value="3">
    Candidato
</option>

                </select>

                <button type="submit" class="btn-submit">
                    Guardar Usuario
                </button>

            </form>

        </div>

    </main>

</div>

</body>
</html>