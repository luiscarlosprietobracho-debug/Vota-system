<?php

session_start();

include("../conexion/conexion.php");

$id = $_GET['id'];

/* CANDIDATO */

$sql = "SELECT * FROM candidato WHERE id_candidato='$id'";
$resultado = mysqli_query($conexion, $sql);

$candidato = mysqli_fetch_assoc($resultado);

/* ELECCIONES */

$sql_elecciones = "SELECT * FROM eleccion";
$elecciones = mysqli_query($conexion, $sql_elecciones);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Candidato</title>

    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>

<div class="container">

    <aside class="sidebar">

        <h2>VotaSystem</h2>

    </aside>

    <main class="main-content">

        <h1>Editar Candidato</h1>

        <div class="form-container">

            <form action="actualizar.php" method="POST">

                <input type="hidden"
                       name="id_candidato"
                       value="<?php echo $candidato['id_candidato']; ?>">

                <label>Nombre</label>

                <input type="text"
                       name="nombre"
                       value="<?php echo $candidato['nombre']; ?>"
                       required>

                <label>Propuesta</label>

                <textarea name="propuesta"><?php echo $candidato['propuesta']; ?></textarea>

                <label>Elección</label>

                <select name="id_eleccion">

                    <?php while($fila = mysqli_fetch_assoc($elecciones)){ ?>

                    <option
                    value="<?php echo $fila['id_eleccion']; ?>"

                    <?php
                    if($fila['id_eleccion'] == $candidato['id_eleccion']){
                        echo "selected";
                    }
                    ?>

                    >

                    <?php echo $fila['titulo']; ?>

                    </option>

                    <?php } ?>

                </select>

                <label>Estado</label>

                <select name="estado">

                    <option value="Activo"
                    <?php if($candidato['estado']=="Activo") echo "selected"; ?>>
                    Activo
                    </option>

                    <option value="Inactivo"
                    <?php if($candidato['estado']=="Inactivo") echo "selected"; ?>>
                    Inactivo
                    </option>

                </select>

                <button type="submit" class="btn-submit">
                    Actualizar
                </button>

            </form>

        </div>

    </main>

</div>

</body>
</html>