<?php

include("../conexion/conexion.php");

/* RECIBIR DATOS */

$nombre = $_POST['nombre'];
$propuesta = $_POST['propuesta'];
$id_eleccion = $_POST['id_eleccion'];
$estado = $_POST['estado'];

/* INSERT */

$sql = "INSERT INTO candidato
(
    id_eleccion,
    nombre,
    propuesta,
    estado
)
VALUES
(
    '$id_eleccion',
    '$nombre',
    '$propuesta',
    '$estado'
)";

$resultado = mysqli_query($conexion, $sql);

if($resultado){

    header("Location: index.php");

}else{

    echo "Error al guardar";

}

?>