<?php

include("../conexion/conexion.php");

$id = $_POST['id_candidato'];

$nombre = $_POST['nombre'];
$propuesta = $_POST['propuesta'];
$id_eleccion = $_POST['id_eleccion'];
$estado = $_POST['estado'];

$sql = "UPDATE candidato SET

nombre='$nombre',
propuesta='$propuesta',
id_eleccion='$id_eleccion',
estado='$estado'

WHERE id_candidato='$id'";

$resultado = mysqli_query($conexion, $sql);

if($resultado){

    header("Location: index.php");

}else{

    echo "Error al actualizar";

}

?>