<?php

session_start();

if(!isset($_SESSION['usuario'])){
    header("Location: ../login.php");
}

include("../conexion/conexion.php");

/* CONSULTA */

$sql = "SELECT candidato.*, eleccion.titulo
FROM candidato
INNER JOIN eleccion
ON candidato.id_eleccion = eleccion.id_eleccion";

$resultado = mysqli_query($conexion, $sql);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Candidatos</title>

    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>

<div class="container">

    <!-- SIDEBAR -->

    <aside class="sidebar">

        <h2>VotaSystem</h2>

        <ul>
            <li><a href="../dashboard/index.php">Dashboard</a></li>
            <li><a href="../elecciones/index.php">Elecciones</a></li>
            <li><a href="../candidatos/index.php">Candidatos</a></li>
            <li><a href="../usuarios/index.php">Usuarios</a></li>
            <li><a href="../reportes/index.php">Reportes</a></li>
            <li><a href="../logout.php">Cerrar sesión</a></li>
        </ul>

    </aside>

    <!-- CONTENIDO -->

    <main class="main-content">

        <header class="top-bar">

            <h1>Gestión de Candidatos</h1>

            <a href="crear.php" class="btn">
                Nuevo Candidato
            </a>

        </header>

        <!-- TABLA -->

        <table>

            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Elección</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>

            <?php while($fila = mysqli_fetch_assoc($resultado)){ ?>

            <tr>

                <td><?php echo $fila['id_candidato']; ?></td>

                <td><?php echo $fila['nombre']; ?></td>

                <td><?php echo $fila['titulo']; ?></td>

                <td><?php echo $fila['estado']; ?></td>

                <td>

                    <a class="btn-editar"
                    href="editar.php?id=<?php echo $fila['id_candidato']; ?>">
                    Editar
                    </a>

                    <a class="btn-eliminar"
                    href="eliminar.php?id=<?php echo $fila['id_candidato']; ?>">
                    Eliminar
                    </a>

                </td>

            </tr>

            <?php } ?>

        </table>

    </main>

</div>

</body>
</html>