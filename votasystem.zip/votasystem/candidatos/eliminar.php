<?php

include("../conexion/conexion.php");

$id = $_GET['id'];

$sql = "DELETE FROM candidato
WHERE id_candidato='$id'";

$resultado = mysqli_query($conexion, $sql);

if($resultado){

    header("Location: index.php");

}else{

    echo "Error al eliminar";

}

?>