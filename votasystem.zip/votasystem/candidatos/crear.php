<?php

session_start();

if(!isset($_SESSION['usuario'])){
    header("Location: ../login.php");
}

include("../conexion/conexion.php");

/* CONSULTAR ELECCIONES */

$sql = "SELECT * FROM eleccion";
$elecciones = mysqli_query($conexion, $sql);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo Candidato</title>

    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>

<div class="container">

    <!-- SIDEBAR -->

    <aside class="sidebar">

        <h2>VotaSystem</h2>

        <ul>
            <li><a href="../dashboard/index.php">Dashboard</a></li>
            <li><a href="../elecciones/index.php">Elecciones</a></li>
            <li><a href="index.php">Candidatos</a></li>
            <li><a href="../usuarios/index.php">Usuarios</a></li>
            <li><a href="../reportes/index.php">Reportes</a></li>
            <li><a href="../logout.php">Cerrar sesión</a></li>
        </ul>

    </aside>

    <!-- CONTENIDO -->

    <main class="main-content">

        <header class="top-bar">
            <h1>Registrar Nuevo Candidato</h1>
        </header>

        <div class="form-container">

            <form action="guardar.php" method="POST">

                <label>Nombre del Candidato</label>
                <input type="text" name="nombre" required>

                <label>Propuesta</label>
                <textarea name="propuesta"></textarea>

                <label>Elección</label>

                <select name="id_eleccion" required>

                    <option value="">Seleccione una elección</option>

                    <?php while($fila = mysqli_fetch_assoc($elecciones)){ ?>

                    <option value="<?php echo $fila['id_eleccion']; ?>">

                        <?php echo $fila['titulo']; ?>

                    </option>

                    <?php } ?>

                </select>

                <label>Estado</label>

                <select name="estado" required>
                    <option value="Activo">Activo</option>
                    <option value="Inactivo">Inactivo</option>
                </select>

                <button type="submit" class="btn-submit">
                    Guardar Candidato
                </button>

            </form>

        </div>

    </main>

</div>

</body>
</html>