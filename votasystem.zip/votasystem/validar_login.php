<?php

session_start();

include("conexion/conexion.php");

/* DATOS */

$correo = $_POST['correo'];
$password = $_POST['password'];

/* CONSULTA */

$sql = "SELECT usuario.*, rol.nombre AS rol_nombre
FROM usuario
INNER JOIN rol
ON usuario.id_rol = rol.id_rol
WHERE correo='$correo'
AND password='$password'";

$resultado = mysqli_query($conexion, $sql);

/* VALIDAR LOGIN */

if(mysqli_num_rows($resultado) > 0){

    $datos = mysqli_fetch_assoc($resultado);

    $_SESSION['usuario'] = $datos['nombre'];
    $_SESSION['id_usuario'] = $datos['id_usuario'];
    $_SESSION['rol'] = $datos['rol_nombre'];

    /* REDIRECCION SEGUN ROL */

    if($datos['rol_nombre'] == "Administrador"){

        header("Location: dashboard/index.php");

    }else{

        header("Location: votacion/index.php");

    }

}else{

    echo "
    <script>

        alert('Correo o contraseña incorrectos');

        window.location='login.php';

    </script>
    ";

}

?>