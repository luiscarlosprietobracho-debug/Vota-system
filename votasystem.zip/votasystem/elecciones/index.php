<?php

session_start();

if(!isset($_SESSION['usuario'])){
    header("Location: ../login.php");
}

include("../conexion/conexion.php");

$sql = "SELECT * FROM eleccion";
$resultado = mysqli_query($conexion, $sql);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elecciones</title>

    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>

<div class="container">

    <!-- SIDEBAR -->

    <aside class="sidebar">

        <h2>VotaSystem</h2>

        <ul>
            <li><a href="../dashboard/index.php">Dashboard</a></li>
            <li><a href="index.php">Elecciones</a></li>
            <li><a href="../candidatos/index.php">Candidatos</a></li>
            <li><a href="../usuarios/index.php">Usuarios</a></li>
            <li><a href="../reportes/index.php">Reportes</a></li>
            <li><a href="../logout.php">Cerrar sesión</a></li>
        </ul>

    </aside>

    <!-- CONTENIDO -->

    <main class="main-content">

        <header class="top-bar">
            <h1>Gestión de Elecciones</h1>

            <a href="crear.php" class="btn">
                Nueva Elección
            </a>
        </header>

        <!-- TABLA -->

        <table>

            <tr>
                <th>ID</th>
                <th>Título</th>
                <th>Fecha Inicio</th>
                <th>Fecha Fin</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>

            <?php while($fila = mysqli_fetch_assoc($resultado)){ ?>

            <tr>
                <td><?php echo $fila['id_eleccion']; ?></td>
                <td><?php echo $fila['titulo']; ?></td>
                <td><?php echo $fila['fecha_inicio']; ?></td>
                <td><?php echo $fila['fecha_fin']; ?></td>
                <td><?php echo $fila['estado']; ?></td>

                <td>

    <a class="btn-editar"
       href="editar.php?id=<?php echo $fila['id_eleccion']; ?>">
       Editar
    </a>

    <a class="btn-eliminar"
       href="eliminar.php?id=<?php echo $fila['id_eleccion']; ?>">
       Eliminar
    </a>

</td>
            </tr>

            <?php } ?>

        </table>

    </main>

</div>

</body>
</html>