<?php

session_start();

include("../conexion/conexion.php");

$id = $_GET['id'];

$sql = "SELECT * FROM eleccion WHERE id_eleccion='$id'";
$resultado = mysqli_query($conexion, $sql);

$fila = mysqli_fetch_assoc($resultado);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Elección</title>

    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>

<div class="container">

    <aside class="sidebar">

        <h2>VotaSystem</h2>

    </aside>

    <main class="main-content">

        <h1>Editar Elección</h1>

        <div class="form-container">

            <form action="actualizar.php" method="POST">

                <input type="hidden"
                       name="id_eleccion"
                       value="<?php echo $fila['id_eleccion']; ?>">

                <label>Título</label>
                <input type="text"
                       name="titulo"
                       value="<?php echo $fila['titulo']; ?>"
                       required>

                <label>Descripción</label>
                <textarea name="descripcion"><?php echo $fila['descripcion']; ?></textarea>

                <label>Fecha Inicio</label>
                <input type="datetime-local"
                       name="fecha_inicio"
                       value="<?php echo date('Y-m-d\TH:i', strtotime($fila['fecha_inicio'])); ?>"
                       required>

                <label>Fecha Fin</label>
                <input type="datetime-local"
                       name="fecha_fin"
                       value="<?php echo date('Y-m-d\TH:i', strtotime($fila['fecha_fin'])); ?>"
                       required>

                <label>Estado</label>

                <select name="estado">

                    <option value="Activa"
                    <?php if($fila['estado']=="Activa") echo "selected"; ?>>
                    Activa
                    </option>

                    <option value="Pendiente"
                    <?php if($fila['estado']=="Pendiente") echo "selected"; ?>>
                    Pendiente
                    </option>

                    <option value="Finalizada"
                    <?php if($fila['estado']=="Finalizada") echo "selected"; ?>>
                    Finalizada
                    </option>

                </select>

                <button type="submit" class="btn-submit">
                    Actualizar
                </button>

            </form>

        </div>

    </main>

</div>

</body>
</html>