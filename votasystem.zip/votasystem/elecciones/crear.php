<?php

session_start();

if(!isset($_SESSION['usuario'])){
    header("Location: ../login.php");
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nueva Elección</title>

    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>

<div class="container">

    <!-- SIDEBAR -->

    <aside class="sidebar">

        <h2>VotaSystem</h2>

        <ul>
            <li><a href="../dashboard/index.php">Dashboard</a></li>
            <li><a href="index.php">Elecciones</a></li>
            <li><a href="../candidatos/index.php">Candidatos</a></li>
            <li><a href="../usuarios/index.php">Usuarios</a></li>
            <li><a href="../reportes/index.php">Reportes</a></li>
            <li><a href="../logout.php">Cerrar sesión</a></li>
        </ul>

    </aside>

    <!-- CONTENIDO -->

    <main class="main-content">

        <header class="top-bar">
            <h1>Registrar Nueva Elección</h1>
        </header>

        <!-- FORMULARIO -->

        <div class="form-container">

            <form action="guardar.php" method="POST">

                <label>Título</label>
                <input type="text" name="titulo" required>

                <label>Descripción</label>
                <textarea name="descripcion"></textarea>

                <label>Fecha de Inicio</label>
                <input type="datetime-local" name="fecha_inicio" required>

                <label>Fecha de Fin</label>
                <input type="datetime-local" name="fecha_fin" required>

                <label>Estado</label>

                <select name="estado" required>
                    <option value="Activa">Activa</option>
                    <option value="Finalizada">Finalizada</option>
                    <option value="Pendiente">Pendiente</option>
                </select>

                <button type="submit" class="btn-submit">
                    Guardar Elección
                </button>

            </form>

        </div>

    </main>

</div>

</body>
</html>