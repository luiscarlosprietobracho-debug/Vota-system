<?php

session_start();

include("../conexion/conexion.php");

/* RECIBIR DATOS */

$titulo = $_POST['titulo'];
$descripcion = $_POST['descripcion'];
$fecha_inicio = $_POST['fecha_inicio'];
$fecha_fin = $_POST['fecha_fin'];
$estado = $_POST['estado'];

/* USUARIO ADMINISTRADOR */

$creado_por = 1;

/* INSERT */

$sql = "INSERT INTO eleccion
(
    titulo,
    descripcion,
    fecha_inicio,
    fecha_fin,
    estado,
    creado_por
)
VALUES
(
    '$titulo',
    '$descripcion',
    '$fecha_inicio',
    '$fecha_fin',
    '$estado',
    '$creado_por'
)";

$resultado = mysqli_query($conexion, $sql);

/* VALIDAR */

if($resultado){

    header("Location: index.php");

}else{

    echo "Error al guardar";

}

?>