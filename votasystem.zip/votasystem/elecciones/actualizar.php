<?php

include("../conexion/conexion.php");

$id = $_POST['id_eleccion'];
$titulo = $_POST['titulo'];
$descripcion = $_POST['descripcion'];
$fecha_inicio = $_POST['fecha_inicio'];
$fecha_fin = $_POST['fecha_fin'];
$estado = $_POST['estado'];

$sql = "UPDATE eleccion SET

titulo='$titulo',
descripcion='$descripcion',
fecha_inicio='$fecha_inicio',
fecha_fin='$fecha_fin',
estado='$estado'

WHERE id_eleccion='$id'";

$resultado = mysqli_query($conexion, $sql);

if($resultado){

    header("Location: index.php");

}else{

    echo "Error al actualizar";

}

?>