<?php

include("../conexion/conexion.php");

$id = $_GET['id'];

$sql = "DELETE FROM eleccion WHERE id_eleccion='$id'";

$resultado = mysqli_query($conexion, $sql);

if($resultado){

    header("Location: index.php");

}else{

    echo "Error al eliminar";

}

?>