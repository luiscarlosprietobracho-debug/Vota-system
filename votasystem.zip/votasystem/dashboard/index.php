<?php
session_start();

if(!isset($_SESSION['usuario'])){
    header("Location: ../login.php");
}

include("../conexion/conexion.php");

/* CONSULTAS */

$usuarios = mysqli_query($conexion, "SELECT * FROM usuario");
$total_usuarios = mysqli_num_rows($usuarios);

$elecciones = mysqli_query($conexion, "SELECT * FROM eleccion");
$total_elecciones = mysqli_num_rows($elecciones);

$candidatos = mysqli_query($conexion, "SELECT * FROM candidato");
$total_candidatos = mysqli_num_rows($candidatos);

$votos = mysqli_query($conexion, "SELECT * FROM voto");
$total_votos = mysqli_num_rows($votos);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - VotaSystem</title>

    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>

<div class="container">

    <!-- SIDEBAR -->

    <aside class="sidebar">

        <h2>VotaSystem</h2>

        <ul>
            <li><a href="index.php">Dashboard</a></li>
<li><a href="../elecciones/index.php">Elecciones</a></li>
<li><a href="../candidatos/index.php">Candidatos</a></li>
<li><a href="../usuarios/index.php">Usuarios</a></li>
<li><a href="../reportes/index.php">Reportes</a></li>
            <li><a href="../logout.php">Cerrar sesión</a></li>
        </ul>

    </aside>

    <!-- MAIN -->

    <main class="main-content">

        <header>
            <h1>Bienvenido, <?php echo $_SESSION['usuario']; ?></h1>
            <p>Administrador del sistema</p>
        </header>

        <!-- CARDS -->

        <section class="cards">

            <div class="card">
                <h3>Usuarios</h3>
                <p><?php echo $total_usuarios; ?></p>
            </div>

            <div class="card">
                <h3>Elecciones</h3>
                <p><?php echo $total_elecciones; ?></p>
            </div>

            <div class="card">
                <h3>Candidatos</h3>
                <p><?php echo $total_candidatos; ?></p>
            </div>

            <div class="card">
                <h3>Votos</h3>
                <p><?php echo $total_votos; ?></p>
            </div>

        </section>

    </main>

</div>

</body>
</html>